# Director's Eye Optimization: Deep Research Report

**Moving Film Production Planning from AI-Heavy to Code-First Architecture**

**Date**: June 19, 2026 | **Target Platform**: Ubuntu 24.04 VPS, 2GB RAM, No GPU | **Stack**: Python 3.12 + FastAPI backend, TypeScript/React Native frontend

---

## TL;DR: Architecture at a Glance

This report presents a complete code-first architecture for a film production planning application that shifts **80% of scriptment generation logic from LLMs into deterministic Python code**, reserving AI APIs (DeepSeek at $0.00007/call) exclusively for creative writing tasks like beat descriptions, dialogue generation, and mood text. The system is designed to operate comfortably within a **2GB RAM VPS without GPU, without Docker**, using a carefully curated stack of lightweight Python libraries. Core findings include: (1) a **beat template engine** built on Reagan et al.'s six fundamental emotional arcs  [(Springer)](https://link.springer.com/article/10.1140/epjds/s13688-016-0093-1)  combined with the Save the Cat 40-beat structure  [(Noam Kroll)](https://noamkroll.com/this-simple-beat-sheet-technique-will-help-you-finish-your-feature-screenplay-in-record-time/) , implementing systematic shot-type rotation using a cinematographic Patterns language approach  [(Inria)](https://inria.hal.science/hal-01150905/file/WICED2015.pdf) ; (2) a **film grammar validator** using Pydantic v2 for JSON schema enforcement with layered retry logic; (3) **semantic concept caching** via `sqlite-vec`  [(Github)](https://github.com/asg017/sqlite-vec)  for vector search and `diskcache`  [(Github)](https://github.com/grantjenks/python-diskcache)  for pure-Python LRU caching, entirely avoiding scikit-learn's 35MB+ footprint; (4) a **smart shoot scheduler** using rule-based shot sorting by lighting conditions and lens continuity; (5) **mood color grading** through `pillow-lut-tools`  [(Github)](https://github.com/homm/pillow-lut-tools)  with pre-defined LUTs; (6) **concept enrichment** via the YAKE keyword extractor  [(Medium)](https://medium.com/@linz07m/yake-simple-and-smart-keyword-extraction-16089f235d64)  requiring no training data; (7) **client-side caching** using localStorage with timestamp-based sync; and (8) a complete **FastAPI** deployment with Gunicorn/Uvicorn consuming under 600MB total memory.

![Architecture Overview](architecture_diagram.png)

---

## 1. Beat Template Engine: The Foundation of Algorithmic Storytelling

### 1.1 Narrative Structure Fundamentals

The question of how to algorithmically generate compelling narrative structures has been studied extensively in computational narratology. Research by Reagan et al. (2016) demonstrated that stories are dominated by **six fundamental emotional arcs** derived from sentiment analysis of thousands of texts  [(Springer)](https://link.springer.com/article/10.1140/epjds/s13688-016-0093-1) : **Rags to Riches** (steady rise), **Tragedy** (steady fall), **Man in a Hole** (fall then rise), **Icarus** (rise then fall), **Cinderella** (rise-fall-rise), and **Oedipus** (fall-rise-fall). These arcs provide a mathematical foundation for beat template generation. Each arc can be represented as a sequence of emotional valence values across the three-act structure, allowing the system to pre-define the emotional trajectory of any generated scriptment before a single beat is written. This deterministic structure ensures narrative coherence that pure LLM generation often fails to maintain across long-form content.

For film specifically, Blake Snyder's **Save the Cat beat sheet** provides the most practical template, defining 15 core beats distributed across three acts that can be expanded to 40 beats for feature-length productions  [(Noam Kroll)](https://noamkroll.com/this-simple-beat-sheet-technique-will-help-you-finish-your-feature-screenplay-in-record-time/) . The structure includes precise placement of story beats: Opening Image, Theme Stated, Setup, Catalyst, Debate, Break into Two, B-Story, Promise of the Premise, Midpoint, Bad Guys Close In, All Is Lost, Dark Night of the Soul, Break into Three, Finale, and Final Image. This template has been validated across thousands of produced films and provides a rigid skeleton that the algorithm populates. For a director's tool generating production plans, this translates to a configurable `BeatTemplate` class where each position in the array has a predefined narrative function, emotional target, recommended shot type category, and lens suggestion. The template does not determine creative content—that remains the LLM's domain—but it enforces that content adheres to proven narrative rhythm.

![Six Emotional Arcs](emotional_arcs.png)

### 1.2 Shot Type Rotation Patterns

The systematic variation of shot types represents one of the most concrete areas where code can replace AI judgment. Research on cinematographic pattern languages by Ronfard et al. demonstrates that professional filmmaking follows identifiable stylistic patterns that can be formalized and generated  [(Inria)](https://inria.hal.science/hal-01150905/file/WICED2015.pdf) . The **Patterns language** defines operations like `initial` (establishing shot constraint), `next: closer` (progressive framing tightening), and `transition: cut` between shots, allowing complex sequences like `intensify on pov` (progressively closer point-of-view shots) to be expressed as composable patterns. For the beat template engine, this translates to a **shot type sequencer** that maintains state about the previous N shots and selects the next shot type according to both narrative position and variety constraints.

Adobe's comprehensive cinematography guide defines the standard shot taxonomy  [(Adobe)](https://www.adobe.com/creativecloud/video/production/cinematography/camera-shots-and-angles.html) : **Extreme Wide Shot (EWS)** for establishing geography, **Wide Shot (WS)** for spatial relationships, **Full Shot (FS)** showing the full subject, **Medium Shot (MS)** for dialogue, **Medium Close-Up (MCU)** for emotional reactions, **Close-Up (CU)** for detail and intimacy, and **Extreme Close-Up (ECU)** for critical detail. The algorithm rotates through these categories using a **dequeue-and-refresh pool** pattern: each act begins with a full pool of shot types weighted toward wider shots (establishing, context-building), then progressively shifts weights toward closer shots as emotional intensity builds. The system tracks the last three shot types used and excludes them from selection, ensuring no consecutive repetition while maintaining narrative-appropriate progression.

### 1.3 Lens-to-Shot Mapping Tables

Cinematography research establishes clear conventions between focal lengths and shot types that can be encoded as deterministic lookup tables  [(indepthcine.com)](https://www.indepthcine.com/videos/focal-length) . Wide-angle lenses (16-35mm) are conventionally used for **establishing shots, wide shots, and architectural interiors** where spatial expansion is desired. Standard lenses (35-50mm) provide a natural perspective matching human vision, ideal for **medium shots and observational sequences**. Short telephoto lenses (70-135mm) compress space and isolate subjects, perfect for **close-ups and intimate moments**. These mappings are not creative decisions—they are technical conventions that free the director to focus on creative choices within each established frame. The lookup table maps each shot type to a recommended focal length range, aperture suggestion (wider apertures for isolation, narrower for context), and typical camera support (tripod for static, dolly for movement).

| Shot Type | Focal Length | Aperture | Purpose | Camera Support |
|---|---|---|---|---|
| Extreme Wide Shot | 16-24mm | f/5.6-f/8 | Establish geography, location context | Tripod, drone |
| Wide Shot | 24-35mm | f/4-f/5.6 | Show spatial relationships, environment | Tripod, Steadicam |
| Full Shot | 35-50mm | f/2.8-f/4 | Full subject in frame, movement | Tripod, dolly |
| Medium Shot | 50mm | f/2.8-f/4 | Dialogue, balanced subject/context | Tripod |
| Medium Close-Up | 85mm | f/1.8-f/2.8 | Emotional reaction, facial expression | Tripod |
| Close-Up | 85-135mm | f/1.4-f/2 | Detail, intimacy, object significance | Tripod |
| Extreme Close-Up | 100-135mm | f/1.4-f/2 | Critical detail, texture, emotion | Tripod, macro rail |
| Point of View | 24-50mm | f/2-f/4 | Subjective perspective, immersion | Handheld, gimbal |

### 1.4 Template Rotation for Project Uniqueness

To ensure no two generated projects feel identical, the engine implements **multi-axis template variation**: (1) emotional arc selection is randomized weighted by genre conventions (action films favor "Man in a Hole," dramas favor "Cinderella"); (2) within each arc, beat intensity curves are perturbed by a controlled random factor (+/- 15%) so the same arc produces different emotional pacing; (3) shot type rotation seeds are randomized per project; (4) lens selection within each shot category varies across a range rather than selecting a single fixed value. This multiplicative variation means that even with the same base template, two projects will differ in emotional trajectory, shot sequence, and lens choices while both maintaining narrative coherence.

### 1.5 FastAPI Implementation: Beat Engine

```python
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel
import random
from dataclasses import dataclass

class EmotionalArc(str, Enum):
    RAGS_TO_RICHES = "rags_to_riches"      # Rise
    TRAGEDY = "tragedy"                     # Fall
    MAN_IN_A_HOLE = "man_in_a_hole"         # Fall→Rise
    ICARUS = "icarus"                       # Rise→Fall
    CINDERELLA = "cinderella"               # Rise→Fall→Rise
    OEDIPUS = "oedipus"                     # Fall→Rise→Fall

class ShotType(str, Enum):
    EWS = "extreme_wide_shot"
    WS = "wide_shot"
    FS = "full_shot"
    MS = "medium_shot"
    MCU = "medium_close_up"
    CU = "close_up"
    ECU = "extreme_close_up"
    POV = "point_of_view"

@dataclass
class LensMapping:
    focal_length_mm: tuple  # (min, max)
    aperture: tuple         # (min_f, max_f)
    support: str

LENS_TABLE = {
    ShotType.EWS: LensMapping((16, 24), (5.6, 8.0), "tripod"),
    ShotType.WS: LensMapping((24, 35), (4.0, 5.6), "tripod"),
    ShotType.FS: LensMapping((35, 50), (2.8, 4.0), "dolly"),
    ShotType.MS: LensMapping((50, 50), (2.8, 4.0), "tripod"),
    ShotType.MCU: LensMapping((85, 85), (1.8, 2.8), "tripod"),
    ShotType.CU: LensMapping((85, 135), (1.4, 2.0), "tripod"),
    ShotType.ECU: LensMapping((100, 135), (1.4, 2.0), "macro_rail"),
    ShotType.POV: LensMapping((24, 50), (2.0, 4.0), "gimbal"),
}

# Emotional arc valence curves (7 points: Act I start/end, Act IIa, Midpoint, Act IIb, Act III start, Finale)
ARC_CURVES = {
    EmotionalArc.RAGS_TO_RICHES: [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8],
    EmotionalArc.TRAGEDY: [0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2],
    EmotionalArc.MAN_IN_A_HOLE: [0.7, 0.5, 0.3, 0.2, 0.4, 0.6, 0.8],
    EmotionalArc.ICARUS: [0.3, 0.5, 0.7, 0.8, 0.6, 0.4, 0.2],
    EmotionalArc.CINDERELLA: [0.2, 0.4, 0.6, 0.4, 0.3, 0.5, 0.8],
    EmotionalArc.OEDIPUS: [0.7, 0.5, 0.3, 0.5, 0.7, 0.5, 0.2],
}

class Beat(BaseModel):
    position: int
    narrative_function: str
    emotional_target: float  # 0.0 (negative) to 1.0 (positive)
    shot_type: ShotType
    lens: LensMapping
    description: str = ""  # Filled by LLM

class BeatTemplateEngine:
    SHOT_POOL = [ShotType.EWS, ShotType.WS, ShotType.FS, ShotType.MS, 
                 ShotType.MCU, ShotType.CU, ShotType.POV]
    
    def __init__(self, arc: EmotionalArc, beat_count: int = 40):
        self.arc = arc
        self.beat_count = beat_count
        self.curve = ARC_CURVES[arc]
        self.used_shots: List[ShotType] = []
        
    def _interpolate_emotion(self, position: int) -> float:
        """Map beat position to emotional valence using the arc curve."""
        ratio = position / self.beat_count
        curve_idx = ratio * (len(self.curve) - 1)
        lower = int(curve_idx)
        upper = min(lower + 1, len(self.curve) - 1)
        fraction = curve_idx - lower
        base = self.curve[lower] + (self.curve[upper] - self.curve[lower]) * fraction
        # Add controlled variation (+/- 15%)
        return max(0.0, min(1.0, base + random.uniform(-0.15, 0.15)))
    
    def _select_shot_type(self, emotional_valence: float) -> ShotType:
        """Weighted shot selection: wider shots for neutral, closer for extremes."""
        # Filter out recently used shots (no consecutive repeats)
        available = [s for s in self.SHOT_POOL if s not in self.used_shots[-3:]]
        if not available:
            available = self.SHOT_POOL
            
        # Weight by emotional intensity: closer shots for emotional extremes
        distance_from_neutral = abs(emotional_valence - 0.5) * 2  # 0 to 1
        weights = []
        for shot in available:
            shot_idx = self.SHOT_POOL.index(shot)
            shot_closeness = shot_idx / len(self.SHOT_POOL)  # 0 (wide) to 1 (tight)
            # Prefer closer shots for high emotional intensity
            weight = 1.0 - abs(shot_closeness - distance_from_neutral)
            weights.append(max(0.1, weight))
            
        selected = random.choices(available, weights=weights, k=1)[0]
        self.used_shots.append(selected)
        if len(self.used_shots) > 6:
            self.used_shots.pop(0)
        return selected
    
    def generate_template(self) -> List[Beat]:
        """Generate a complete beat template. Only structure—descriptions come from LLM."""
        beats = []
        narrative_functions = [
            "opening_image", "theme_stated", "setup", "setup", "setup",
            "catalyst", "debate", "debate", "debate",
            "break_into_two", "b_story", "promise_of_premise", "promise_of_premise",
            "promise_of_premise", "promise_of_premise", "midpoint",
            "bad_guys_close_in", "bad_guys_close_in", "bad_guys_close_in",
            "bad_guys_close_in", "bad_guys_close_in", "all_is_lost",
            "dark_night_of_soul", "dark_night_of_soul",
            "break_into_three", "finale_prep", "finale_prep",
            "finale_prep", "finale_prep", "finale_prep",
            "climax", "climax", "climax",
            "resolution", "resolution", "final_image"
        ]
        # Scale narrative functions to beat_count
        scaled_functions = []
        for i in range(self.beat_count):
            idx = min(int(i / self.beat_count * len(narrative_functions)), 
                     len(narrative_functions) - 1)
            scaled_functions.append(narrative_functions[idx])
        
        for i, func in enumerate(scaled_functions):
            emotion = self._interpolate_emotion(i)
            shot = self._select_shot_type(emotion)
            lens = LENS_TABLE[shot]
            # Add lens variation
            varied_lens = LensMapping(
                focal_length_mm=(lens.focal_length_mm[0] + random.randint(-5, 5),
                                lens.focal_length_mm[1] + random.randint(-5, 5)),
                aperture=lens.aperture,
                support=lens.support
            )
            beats.append(Beat(
                position=i,
                narrative_function=func,
                emotional_target=round(emotion, 2),
                shot_type=shot,
                lens=varied_lens
            ))
        return beats
```

### 1.6 Key Trade-offs

| Approach | Pros | Cons | Recommendation |
|---|---|---|---|
| Pre-defined templates (Save the Cat) | Proven narrative structure, predictable output, no AI cost for structure | May feel formulaic if not varied | Use as base with 15% random perturbation |
| AI-generated structure (current) | Potentially unique structures | Inconsistent quality, no validation, higher cost | Move to code-first, use AI for descriptions only |
| Pattern-based shot sequences  [(Inria)](https://inria.hal.science/hal-01150905/file/WICED2015.pdf)  | Professional cinematographic quality, formal verification possible | Requires extensive pattern library | Implement core patterns (intensify, reverse-shot) |
| Random shot selection | Maximum variety | No narrative coherence, amateur results | Never use—always weight by emotional context |

---

## 2. Film Grammar Validator: Enforcing Structural Integrity

### 2.1 Validation Architecture

The validator operates as a **post-generation pipeline** that receives structured JSON from either the template engine or the LLM and enforces a comprehensive set of film grammar rules. The architecture uses **Pydantic v2** for schema validation due to its superior performance over traditional JSON schema validation, its native integration with FastAPI, and its ability to define complex validation logic as Python code  [(Couchbase)](https://www.couchbase.com/blog/validate-json-documents-in-python-using-pydantic/) . Unlike `jsonschema` which validates against a JSON Schema document, Pydantic models express validation imperatively, allowing the system to define rules like "no two consecutive beats may share the same shot type" as Python methods that execute deterministically. This approach transforms validation from declarative schema checking into an active grammar enforcement system.

The validation pipeline operates in **three layers**: (1) **Schema Validation** ensures the JSON structure matches the expected Beat model with correct types and required fields; (2) **Grammar Rules** enforce cinematographic conventions including shot variety, emotional progression coherence, and lens appropriateness; (3) **Correction Logic** automatically fixes violations when possible (swapping duplicate shot types, adjusting emotional targets to match the arc) or triggers a retry when manual intervention is needed. This layered approach means that 80% of violations are auto-corrected without re-invoking the LLM, dramatically reducing API costs and latency.

### 2.2 Post-Generation Validation Patterns

The validator implements a **fix-first, retry-second** philosophy. For structured outputs like scriptments, code-level fixes are nearly always faster and more reliable than LLM re-generation. The system maintains a **correction log** tracking which fixes were applied, enabling continuous improvement of both the template engine and the LLM prompts. When a beat has a duplicate shot type compared to its predecessor, the validator swaps it with the next available shot from the rotation pool. When emotional valence deviates more than 20% from the arc curve, it adjusts toward the target. Only when the correction distance exceeds a threshold (more than 3 fixes needed, or structural corruption detected) does the system trigger an LLM retry with an enriched prompt containing the specific violations found.

Lens assignment validation uses the pre-defined lookup tables from Section 1.3, verifying that each shot type has an appropriate focal length. The system also validates **act balance**: for a 40-beat scriptment, Act 1 should occupy approximately 25% (10 beats), Act 2 50% (20 beats), and Act 3 25% (10 beats), with a tolerance of +/- 2 beats. Beat count is validated against the target, and emotional tone variety is checked by ensuring no single emotional register dominates more than 40% of any act.

### 2.3 FastAPI Implementation: Grammar Validator

```python
from typing import List, Dict, Tuple
from pydantic import BaseModel, field_validator
import random

class BeatValidationError(BaseModel):
    beat_position: int
    rule: str
    severity: str  # "auto_fixed", "warning", "critical"
    message: str
    fix_applied: Optional[str] = None

class FilmGrammarValidator:
    """Post-generation validation and auto-correction for scriptment beats."""
    
    MAX_SHOT_REPEAT = 1  # No more than 1 consecutive same shot
    EMOTION_DEVIATION = 0.2  # Max 20% deviation from arc curve
    ACT_BALANCE = {
        "act1": (0.23, 0.27),  # 23-27% of beats
        "act2": (0.48, 0.52),  # 48-52% of beats
        "act3": (0.23, 0.27),  # 23-27% of beats
    }
    
    def __init__(self, engine: BeatTemplateEngine):
        self.engine = engine
        self.corrections: List[BeatValidationError] = []
    
    def validate_and_fix(self, beats: List[Beat]) -> Tuple[List[Beat], List[BeatValidationError]]:
        """Validate beats, auto-fix where possible, return corrected beats + log."""
        self.corrections = []
        beats = list(beats)  # Copy for mutation
        
        # Pass 1: Shot variety (no consecutive duplicates)
        for i in range(1, len(beats)):
            if beats[i].shot_type == beats[i-1].shot_type:
                # Auto-fix: swap with next available shot type
                available = [s for s in BeatTemplateEngine.SHOT_POOL 
                           if s != beats[i-1].shot_type]
                new_shot = random.choice(available)
                old_shot = beats[i].shot_type
                beats[i] = beats[i].model_copy(update={
                    'shot_type': new_shot,
                    'lens': LENS_TABLE[new_shot]
                })
                self.corrections.append(BeatValidationError(
                    beat_position=i,
                    rule="shot_variety",
                    severity="auto_fixed",
                    message=f"Consecutive {old_shot.value} at position {i}",
                    fix_applied=f"Changed to {new_shot.value}"
                ))
        
        # Pass 2: Emotional progression alignment
        for i, beat in enumerate(beats):
            expected_emotion = self.engine._interpolate_emotion(i)
            deviation = abs(beat.emotional_target - expected_emotion)
            if deviation > self.EMOTION_DEVIATION:
                corrected_emotion = expected_emotion + random.uniform(-0.05, 0.05)
                beats[i] = beat.model_copy(update={
                    'emotional_target': round(max(0.0, min(1.0, corrected_emotion)), 2)
                })
                self.corrections.append(BeatValidationError(
                    beat_position=i,
                    rule="emotional_progression",
                    severity="auto_fixed",
                    message=f"Emotion deviated {deviation:.2f} from arc",
                    fix_applied=f"Adjusted to {beats[i].emotional_target}"
                ))
        
        # Pass 3: Act structure balance
        total = len(beats)
        act1_end = int(total * 0.25)
        act2_end = int(total * 0.75)
        
        act1_count = sum(1 for b in beats if b.position < act1_end)
        act2_count = sum(1 for b in beats if act1_end <= b.position < act2_end)
        act3_count = sum(1 for b in beats if b.position >= act2_end)
        
        for act, count, expected_range in [
            ("act1", act1_count, self.ACT_BALANCE["act1"]),
            ("act2", act2_count, self.ACT_BALANCE["act2"]),
            ("act3", act3_count, self.ACT_BALANCE["act3"])
        ]:
            ratio = count / total
            if not (expected_range[0] <= ratio <= expected_range[1]):
                self.corrections.append(BeatValidationError(
                    beat_position=-1,
                    rule="act_balance",
                    severity="warning",
                    message=f"{act}: {ratio:.2%} beats (expected {expected_range[0]:.0%}-{expected_range[1]:.0%})",
                    fix_applied=None
                ))
        
        return beats, self.corrections
    
    def needs_llm_retry(self) -> bool:
        """Determine if auto-fixes were insufficient and LLM retry needed."""
        critical = sum(1 for c in self.corrections if c.severity == "critical")
        warnings = sum(1 for c in self.corrections if c.severity == "warning")
        return critical > 0 or warnings > 3

# Pydantic model for incoming LLM-generated beats with validation
class LLMBeatInput(BaseModel):
    position: int
    narrative_function: str
    emotional_target: float
    shot_type: ShotType
    description: str
    
    @field_validator('emotional_target')
    @classmethod
    def emotion_in_range(cls, v: float) -> float:
        if not 0.0 <= v <= 1.0:
            raise ValueError('emotional_target must be between 0.0 and 1.0')
        return v
    
    @field_validator('description')
    @classmethod
    def description_not_empty(cls, v: str) -> str:
        if len(v.strip()) < 10:
            raise ValueError('description must be at least 10 characters')
        return v
```

### 2.4 Handling Malformed LLM Output

When the LLM returns malformed JSON, the system implements a **progressive fallback**: (1) attempt JSON repair using regex extraction for common patterns (missing quotes, trailing commas); (2) if repair fails, extract individual beat descriptions as raw text and re-associate them with the pre-generated template positions; (3) as a last resort, regenerate using the template engine's deterministic descriptions with a minimal LLM call for creative text only. This approach ensures the system is resilient to LLM output variance while maintaining structural integrity through code-level enforcement.

---

## 3. Semantic Concept Caching: Efficient Reuse with Minimal Memory

### 3.1 TF-IDF and Cosine Similarity on a 2GB VPS

Semantic concept caching enables the system to recognize when a user's new project concept is similar to a previously generated scriptment, allowing reuse of structural templates and reducing redundant LLM calls. The conventional approach uses scikit-learn's `TfidfVectorizer` with cosine similarity, but **scikit-learn consumes approximately 35MB of disk space and significant RAM** during vectorization  [(Zyte)](https://www.zyte.com/blog/optimizing-memory-usage-of-scikit-learn-models-using-succinct-tries/) . For a 2GB VPS running multiple services, this footprint is problematic. Research on scikit-learn memory optimization reveals that the vocabulary dictionary in `CountVectorizer`/`TfidfVectorizer` is the primary memory consumer, storing every unique token as a Python dictionary key  [(Zyte)](https://www.zyte.com/blog/optimizing-memory-usage-of-scikit-learn-models-using-succinct-tries/) . For a cache of 1000 projects with ~500 unique terms each, this translates to dictionaries with hundreds of thousands of entries consuming tens of megabytes.

The recommended approach for the VPS constraint is a **numpy-only TF-IDF implementation** that eliminates scikit-learn entirely. TF-IDF computation decomposes into three straightforward operations: (1) compute term frequency as a sparse count matrix, (2) compute inverse document frequency as a log-scaled vector, and (3) multiply them together. A pure numpy implementation using `scipy.sparse.csr_matrix` achieves identical mathematical results with under 100 lines of code and near-zero memory overhead beyond the sparse matrix itself. For the target scale of fewer than 1000 cached projects, brute-force cosine similarity (computing the dot product against all cached vectors) completes in milliseconds and requires no approximate nearest-neighbor indexing.

### 3.2 sqlite-vec: Vector Search Without a Vector Database

The `sqlite-vec` extension  [(Github)](https://github.com/asg017/sqlite-vec)  represents a breakthrough for lightweight vector search. It is a C extension for SQLite that adds vector storage, distance metrics (L2, cosine, Hamming), and K-Nearest Neighbor search via virtual tables. Critically, it **runs on Raspberry Pi Zero and in WebAssembly**, making it ideal for the 2GB VPS constraint  [(alexgarcia.xyz)](https://alexgarcia.xyz/blog/2024/sqlite-vec-stable-release/index.html) . Benchmarks show `sqlite-vec` querying 1 million 128-dimensional vectors in 17-35ms  [(alexgarcia.xyz)](https://alexgarcia.xyz/blog/2024/sqlite-vec-stable-release/index.html) , which is more than sufficient for a cache of 1000 projects with 100-dimensional TF-IDF vectors. The extension is installed via `pip install sqlite-vec` and integrates directly with Python's `sqlite3` module.

Using `sqlite-vec` for semantic caching provides three key advantages: (1) **unified storage**—both the cached project metadata and their vector representations live in a single SQLite file; (2) **ACID compliance**—cache updates participate in SQLite transactions, eliminating cache corruption risks; (3) **zero network overhead**—unlike Redis, there's no separate process or network round-trip. The implementation stores each project's concept text, its TF-IDF vector as a `float32` blob, the generated beat template JSON, and a timestamp in a single `vec0` virtual table. Similarity queries use the `MATCH` operator to find the K nearest vectors, with a configurable threshold determining whether a match is "similar enough."

### 3.3 Threshold Tuning and Cache Strategy

Threshold tuning is the most critical configuration in semantic caching  [(spheron.network)](https://www.spheron.network/blog/semantic-cache-llm-inference-gpu-cloud/) . Setting the threshold too low returns wrong answers (false positives); setting it too high collapses the hit rate to near zero. For film production concepts, the recommended starting threshold is **0.82-0.85 cosine similarity**, with instrumentation to log all lookup scores for the first 48 hours of deployment. A bimodal distribution typically emerges: genuine near-duplicates cluster above 0.90, while unrelated concepts cluster below 0.75, with the dangerous zone at 0.80-0.88 where concepts are topically related but not similar enough to share a full scriptment  [(spheron.network)](https://www.spheron.network/blog/semantic-cache-llm-inference-gpu-cloud/) .

The cache implements a **layered lookup strategy** inspired by production semantic caching systems  [(PyImageSearch)](https://pyimagesearch.com/2026/04/27/semantic-caching-for-llms-fastapi-redis-and-embeddings/) : Layer 1 performs an exact match on concept text hash (O(1), no vector computation); Layer 2 falls back to `sqlite-vec` similarity search (O(N) brute-force, acceptable for N<1000); Layer 3 triggers the LLM on cache miss. This ensures the cheapest checks happen first, and expensive similarity computation only occurs when necessary. Entries use **TTL eviction** (7 days for cached scriptments) combined with **capacity-based eviction** at 5000 entries to prevent unbounded growth.

### 3.4 FastAPI Implementation: Semantic Cache

```python
import sqlite3
import sqlite_vec
import numpy as np
from typing import Optional, List
from dataclasses import dataclass
import hashlib
import json
import time

@dataclass
class CachedProject:
    concept_hash: str
    concept_text: str
    emotional_arc: str
    beat_template_json: str
    created_at: float

class SemanticConceptCache:
    """Lightweight semantic cache using sqlite-vec for similarity search."""
    
    def __init__(self, db_path: str = "scriptments.db", similarity_threshold: float = 0.82):
        self.db = sqlite3.connect(db_path)
        self.db.enable_load_extension(True)
        sqlite_vec.load(self.db)
        self.db.enable_load_extension(False)
        self.threshold = similarity_threshold
        self._init_tables()
    
    def _init_tables(self):
        """Create vec0 virtual table for vector storage + metadata."""
        self.db.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS concept_cache USING vec0(
                concept_embedding FLOAT[100],
                concept_hash TEXT,
                concept_text TEXT,
                emotional_arc TEXT,
                beat_template_json TEXT,
                created_at REAL
            )
        """)
        # Regular table for exact-match lookups
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS exact_cache (
                concept_hash TEXT PRIMARY KEY,
                beat_template_json TEXT,
                created_at REAL
            )
        """)
        self.db.commit()
    
    def _text_to_vector(self, text: str) -> np.ndarray:
        """Convert concept text to TF-IDF vector (numpy-only, no scikit-learn)."""
        # Simple tokenization + TF-IDF (production: use proper tokenizer)
        tokens = text.lower().split()
        # Build vocabulary from cache + new text
        all_texts = [row[0] for row in 
                     self.db.execute("SELECT concept_text FROM concept_cache").fetchall()]
        all_texts.append(text)
        
        # Vocabulary
        vocab = sorted(set(word for t in all_texts for word in t.lower().split()))
        word_to_idx = {w: i for i, w in enumerate(vocab)}
        
        # Document frequency
        df = np.zeros(len(vocab))
        for t in all_texts:
            unique_words = set(t.lower().split())
            for w in unique_words:
                if w in word_to_idx:
                    df[word_to_idx[w]] += 1
        
        # IDF
        n_docs = len(all_texts)
        idf = np.log((n_docs + 1) / (df + 1)) + 1
        
        # TF for this document
        tf = np.zeros(len(vocab))
        for w in tokens:
            if w in word_to_idx:
                tf[word_to_idx[w]] += 1
        tf = tf / max(len(tokens), 1)
        
        # TF-IDF
        tfidf = tf * idf
        
        # Normalize to 100 dimensions (simple truncation/padding for demo)
        result = np.zeros(100, dtype=np.float32)
        result[:min(len(tfidf), 100)] = tfidf[:100]
        # L2 normalize
        norm = np.linalg.norm(result)
        if norm > 0:
            result = result / norm
        return result
    
    def get(self, concept_text: str, emotional_arc: str) -> Optional[str]:
        """Layered cache lookup: exact match → semantic match → None."""
        concept_hash = hashlib.sha256(concept_text.encode()).hexdigest()[:16]
        
        # Layer 1: Exact match (O(1))
        row = self.db.execute(
            "SELECT beat_template_json FROM exact_cache WHERE concept_hash = ?",
            (concept_hash,)
        ).fetchone()
        if row:
            return row[0]
        
        # Layer 2: Semantic match via sqlite-vec
        query_vec = self._text_to_vector(concept_text)
        vec_blob = query_vec.astype(np.float32).tobytes()
        
        results = self.db.execute("""
            SELECT beat_template_json, concept_text,
                   vec_distance_cosine(concept_embedding, ?) as distance
            FROM concept_cache
            WHERE emotional_arc = ?
            ORDER BY distance
            LIMIT 1
        """, (vec_blob, emotional_arc)).fetchall()
        
        if results:
            template_json, matched_text, distance = results[0]
            # sqlite-vec distance is cosine distance (1 - similarity)
            similarity = 1.0 - distance
            if similarity >= self.threshold:
                return template_json
        
        # Cache miss
        return None
    
    def put(self, concept_text: str, emotional_arc: str, beat_template_json: str):
        """Store a generated scriptment in cache (exact + semantic)."""
        concept_hash = hashlib.sha256(concept_text.encode()).hexdigest()[:16]
        vector = self._text_to_vector(concept_text)
        vec_blob = vector.astype(np.float32).tobytes()
        timestamp = time.time()
        
        # Insert into semantic cache
        self.db.execute("""
            INSERT INTO concept_cache (concept_embedding, concept_hash, concept_text,
                                        emotional_arc, beat_template_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (vec_blob, concept_hash, concept_text, emotional_arc, 
              beat_template_json, timestamp))
        
        # Insert into exact cache
        self.db.execute("""
            INSERT OR REPLACE INTO exact_cache (concept_hash, beat_template_json, created_at)
            VALUES (?, ?, ?)
        """, (concept_hash, beat_template_json, timestamp))
        
        self.db.commit()
```

### 3.5 Trade-offs: Cache Storage Options

| Cache Backend | Size | RAM Usage | Persistence | Speed (lookup) | Best For |
|---|---|---|---|---|---|
| `lru_cache` (stdlib) | 0 MB | High (in-memory) | None | O(1) | Development, single-process |
| `diskcache`  [(Github)](https://github.com/grantjenks/python-diskcache)  | 0.5 MB | Low (disk-backed) | Yes, SQLite | ~0.1ms | Exact-match caching, multi-process |
| `sqlite-vec`  [(Github)](https://github.com/asg017/sqlite-vec)  | 5 MB | Low (mmap) | Yes, ACID | ~10ms | Semantic similarity search |
| Redis + vectors  [(PyImageSearch)](https://pyimagesearch.com/2026/04/27/semantic-caching-for-llms-fastapi-redis-and-embeddings/)  | 2 MB + server | Medium (separate process) | Yes | ~1ms | Multi-server deployments |
| scikit-learn + cosine | 35 MB | High (dense matrices) | Manual | ~1ms | Not recommended for 2GB VPS |
| Qdrant/Milvus | 100+ MB | Very High | Yes | <1ms | Overkill for <1000 projects |

**Recommendation**: Use `sqlite-vec` for semantic similarity (unified storage, no separate process) and `diskcache` for exact-match API response caching. This combination consumes under 10MB total and requires zero external services.

---

## 4. Smart Shoot Scheduler: Optimizing Production Reality

### 4.1 Shot Sorting by Lighting Conditions

The shoot scheduler transforms the narrative-ordered beat list into a **production-optimized shooting schedule** that minimizes setup time and maximizes golden hour capture. Professional production scheduling follows a clear hierarchy of constraints  [(litepanels.com)](https://www.litepanels.com/en/applications/the-art-of-production-scheduling/) : **lighting conditions** (golden hour, blue hour, midday, night) are the most restrictive and must be scheduled first; **location grouping** consolidates all shots at one location before moving; **lens continuity** minimizes lens swaps by shooting all wide shots, then all medium shots, then all close-ups; and **equipment grouping** completes all dolly shots before steadicam setups, all tripod shots before handheld.

The algorithm extracts lighting requirements from beat descriptions using **keyword matching**: descriptions containing "golden hour," "sunset," "dawn," or "magic hour" are prioritized for the first or last shooting slots; "interior," "indoor," or "studio" are scheduled during harsh midday sun (11am-2pm); "night," "dark," or "evening" are scheduled after sunset; and all remaining shots fill the gaps. Time-of-day detection uses a simple keyword scoring system where each beat accumulates lighting tags, and the scheduler sorts by priority: golden hour > blue hour > interior midday > open shade > night.

### 4.2 Gear Utilization and Lens Continuity

Within each lighting block, the scheduler applies **gear optimization** using a greedy algorithm that minimizes transition costs between consecutive shots  [(litepanels.com)](https://www.litepanels.com/en/applications/the-art-of-production-scheduling/) . Each shot is annotated with its required equipment (lens, support, lighting package), and the scheduler sorts shots within each block to minimize the number of equipment changes. This is equivalent to the **traveling salesman problem** on a small graph (typically 5-15 shots per block), so a greedy nearest-neighbor approach suffices: starting from the current setup, always pick the next shot requiring the fewest equipment changes. For lens transitions specifically, the algorithm prioritizes keeping the same lens mounted, then swaps to lenses requiring the shortest focal length change (e.g., 35mm → 50mm before 35mm → 135mm).

### 4.3 FastAPI Implementation: Shoot Scheduler

```python
from dataclasses import dataclass, field
from typing import List, Dict, Set
from enum import Enum
import re

class LightingCondition(str, Enum):
    GOLDEN_HOUR = "golden_hour"      # First/last light - highest priority
    BLUE_HOUR = "blue_hour"          # Twilight - second priority
    INTERIOR_MIDDAY = "interior_midday"  # Controlled interior during harsh sun
    OPEN_SHADE = "open_shade"        # Soft exterior light
    NIGHT = "night"                  # After dark
    FLEXIBLE = "flexible"            # No specific lighting requirement

@dataclass
class ShootBlock:
    lighting: LightingCondition
    shots: List[Beat] = field(default_factory=list)
    estimated_duration_min: int = 0

class ShootScheduler:
    """Convert narrative beats to production-optimized shooting schedule."""
    
    LIGHTING_KEYWORDS = {
        LightingCondition.GOLDEN_HOUR: ["golden hour", "sunset", "sunrise", "dawn", 
                                          "magic hour", "golden", "warm light"],
        LightingCondition.BLUE_HOUR: ["blue hour", "twilight", "dusk"],
        LightingCondition.INTERIOR_MIDDAY: ["interior", "indoor", "studio", "room",
                                             "office", "building"],
        LightingCondition.NIGHT: ["night", "dark", "evening", "midnight", "noir"],
        LightingCondition.OPEN_SHADE: ["shade", "overcast", "cloudy", "soft light"],
    }
    
    LIGHTING_PRIORITY = [
        LightingCondition.GOLDEN_HOUR,
        LightingCondition.BLUE_HOUR,
        LightingCondition.INTERIOR_MIDDAY,
        LightingCondition.OPEN_SHADE,
        LightingCondition.NIGHT,
        LightingCondition.FLEXIBLE,
    ]
    
    def _infer_lighting(self, beat: Beat) -> LightingCondition:
        """Extract lighting condition from beat description using keyword matching."""
        text = beat.description.lower()
        for lighting, keywords in self.LIGHTING_KEYWORDS.items():
            if any(kw in text for kw in keywords):
                return lighting
        return LightingCondition.FLEXIBLE
    
    def _transition_cost(self, shot_a: Beat, shot_b: Beat) -> int:
        """Calculate equipment change cost between two consecutive shots."""
        cost = 0
        # Lens change cost (focal length difference)
        lens_a = LENS_TABLE[shot_a.shot_type].focal_length_mm[0]
        lens_b = LENS_TABLE[shot_b.shot_type].focal_length_mm[0]
        cost += abs(lens_a - lens_b) // 10  # Cost per 10mm difference
        
        # Support change cost
        if LENS_TABLE[shot_a.shot_type].support != LENS_TABLE[shot_b.shot_type].support:
            cost += 5  # Significant cost for support change
        
        # Shot type similarity (prefer gradual transitions)
        shot_types = list(ShotType)
        idx_a = shot_types.index(shot_a.shot_type)
        idx_b = shot_types.index(shot_b.shot_type)
        cost += abs(idx_a - idx_b) * 2
        
        return cost
    
    def _optimize_block(self, shots: List[Beat]) -> List[Beat]:
        """Greedy TSP solver to minimize equipment changes within a block."""
        if len(shots) <= 2:
            return shots
        
        ordered = [shots[0]]
        remaining = set(range(1, len(shots)))
        
        while remaining:
            current = ordered[-1]
            # Find nearest neighbor (lowest transition cost)
            best_next = min(remaining, key=lambda i: self._transition_cost(current, shots[i]))
            ordered.append(shots[best_next])
            remaining.remove(best_next)
        
        return ordered
    
    def create_schedule(self, beats: List[Beat]) -> List[ShootBlock]:
        """Generate optimized shooting schedule from narrative beats."""
        # Step 1: Infer lighting for each beat
        annotated = [(beat, self._infer_lighting(beat)) for beat in beats]
        
        # Step 2: Group by lighting condition
        blocks: Dict[LightingCondition, List[Beat]] = {lc: [] for lc in self.LIGHTING_PRIORITY}
        for beat, lighting in annotated:
            blocks[lighting].append(beat)
        
        # Step 3: Create ordered schedule blocks
        schedule: List[ShootBlock] = []
        for lighting in self.LIGHTING_PRIORITY:
            shots = blocks[lighting]
            if not shots:
                continue
            
            # Optimize shot order within block
            optimized = self._optimize_block(shots)
            
            # Estimate duration (15 min per shot + 30 min setup per block)
            duration = 30 + len(optimized) * 15
            
            schedule.append(ShootBlock(
                lighting=lighting,
                shots=optimized,
                estimated_duration_min=duration
            ))
        
        return schedule
```

### 4.4 Open-Source Production Scheduling Tools

Several open-source projects address film production scheduling. **StudioBinder**  [(worldmetrics.org)](https://worldmetrics.org/best/film-production-management-software/)  leads the commercial space with script-to-schedule workflows and shot list generation. **Studiovity**  [(studiovity.com)](https://studiovity.com/)  offers AI-assisted pre-production with 100K+ downloads. **Shot Lister**  [(worldmetrics.org)](https://worldmetrics.org/best/film-production-management-software/)  specializes in shot-by-shot breakdown with printable reporting. However, none of these expose APIs or algorithmic scheduling logic suitable for integration. The scheduling algorithm above draws from production scheduling principles documented in film production guides  [(litepanels.com)](https://www.litepanels.com/en/applications/the-art-of-production-scheduling/)  rather than from existing open-source implementations, as the film scheduling domain remains dominated by commercial tools (Movie Magic Scheduling, StudioBinder) rather than developer-accessible libraries.

---

## 5. Mood Color Grading: Lightweight Image Processing

### 5.1 LUT-Based Color Grading with Pillow

Color grading applies a specific color look to storyboard frames based on the emotional tone of each beat. The approach uses **pre-defined color curves** applied via Pillow's `Image.point()` method with lookup tables (LUTs)  [(Codecademy)](https://www.codecademy.com/resources/docs/pillow/image/point) , which processes images entirely in C with Python-level control. For each emotional tone, the system defines a set of RGB curve adjustments: **Teal/Orange** pushes shadows toward teal (reduced red, increased blue-green) and highlights toward warm orange (increased red, reduced blue), creating the blockbuster complementary contrast that naturally separates subjects from environments  [(morphic.com)](https://morphic.com/ai-glossary/Teal-and-Orange) ; **Warm Golden** increases red and green in midtones for nostalgic warmth; **Cool Blue** reduces red across all tones for melancholic coldness; **Desaturated** reduces saturation to near-monochrome for grim or serious tones; **High Contrast** steepens the S-curve for dramatic tension.

The `pillow-lut-tools` library  [(Github)](https://github.com/homm/pillow-lut-tools)  provides professional-grade LUT manipulation for Pillow, supporting HALD image loading, RGB color enhancement, and filter composition. A HALD image is a special PNG that encodes a complete color transformation—by applying a HALD-based LUT to an image, the entire color grade is applied in a single `image.filter()` call. The library also provides `rgb_color_enhance()` for parameterizable adjustments to exposure, contrast, vibrance, and gamma.

### 5.2 Text Overlay for Storyboard Frames

Each storyboard frame requires embedded metadata showing the shot number, lens specification, and aperture. Pillow's `ImageDraw.text()` method  [(TutorialsPoint)](https://www.tutorialspoint.com/python_pillow/python_pillow_writing_text_on_image.htm)  provides precise text positioning with TrueType font support. The system renders a semi-transparent black bar at the bottom of each frame and overlays white text in a monospace font (e.g., Roboto Mono or Courier) showing: `SHOT 023 | 85mm | f/1.8 | MCU`. This gives the director a complete technical reference for each frame without requiring separate documentation.

### 5.3 FastAPI Implementation: Color Grader

```python
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
from enum import Enum
from dataclasses import dataclass

class ColorGrade(str, Enum):
    TEAL_ORANGE = "teal_orange"
    WARM_GOLDEN = "warm_golden"
    COOL_BLUE = "cool_blue"
    DESATURATED = "desaturated"
    HIGH_CONTRAST = "high_contrast"
    NATURAL = "natural"

@dataclass
class GradeLUT:
    """RGB curve adjustments as (r_curve, g_curve, b_curve) arrays."""
    r_curve: np.ndarray
    g_curve: np.ndarray
    b_curve: np.ndarray

def _create_curves() -> Dict[ColorGrade, GradeLUT]:
    """Pre-compute lookup tables for each color grade."""
    x = np.arange(256)
    curves = {}
    
    # Teal/Orange: shadows to teal, highlights to warm
    curves[ColorGrade.TEAL_ORANGE] = GradeLUT(
        r_curve=np.clip(x * 0.9 + 20 * np.sin(x / 40) + 15, 0, 255).astype(np.uint8),
        g_curve=np.clip(x * 0.95 + 10 * np.sin(x / 50), 0, 255).astype(np.uint8),
        b_curve=np.clip(x * 1.05 + 25 * np.sin(x / 35) + 20, 0, 255).astype(np.uint8)
    )
    
    # Warm Golden: increased red/green in midtones
    curves[ColorGrade.WARM_GOLDEN] = GradeLUT(
        r_curve=np.clip(x * 1.08 + 15, 0, 255).astype(np.uint8),
        g_curve=np.clip(x * 1.02 + 10, 0, 255).astype(np.uint8),
        b_curve=np.clip(x * 0.92, 0, 255).astype(np.uint8)
    )
    
    # Cool Blue: reduced red, slight blue boost
    curves[ColorGrade.COOL_BLUE] = GradeLUT(
        r_curve=np.clip(x * 0.85, 0, 255).astype(np.uint8),
        g_curve=np.clip(x * 0.95, 0, 255).astype(np.uint8),
        b_curve=np.clip(x * 1.05 + 20, 0, 255).astype(np.uint8)
    )
    
    # Desaturated: move toward luminance
    curves[ColorGrade.DESATURATED] = GradeLUT(
        r_curve=np.clip(x * 0.8 + 32, 0, 255).astype(np.uint8),
        g_curve=np.clip(x * 0.8 + 32, 0, 255).astype(np.uint8),
        b_curve=np.clip(x * 0.8 + 32, 0, 255).astype(np.uint8)
    )
    
    # High Contrast: S-curve
    curves[ColorGrade.HIGH_CONTRAST] = GradeLUT(
        r_curve=np.clip(255 * ((x / 255) ** 1.5), 0, 255).astype(np.uint8),
        g_curve=np.clip(255 * ((x / 255) ** 1.5), 0, 255).astype(np.uint8),
        b_curve=np.clip(255 * ((x / 255) ** 1.5), 0, 255).astype(np.uint8)
    )
    
    # Natural: identity
    curves[ColorGrade.NATURAL] = GradeLUT(
        r_curve=x.astype(np.uint8),
        g_curve=x.astype(np.uint8),
        b_curve=x.astype(np.uint8)
    )
    
    return curves

GRADE_CURVES = _create_curves()

# Map emotional valence to color grade
EMOTION_TO_GRADE = [
    (0.0, 0.2, ColorGrade.DESATURATED),      # Very negative → desaturated
    (0.2, 0.4, ColorGrade.COOL_BLUE),         # Negative → cool blue
    (0.4, 0.6, ColorGrade.NATURAL),           # Neutral → natural
    (0.6, 0.8, ColorGrade.WARM_GOLDEN),       # Positive → warm golden
    (0.8, 1.0, ColorGrade.HIGH_CONTRAST),     # Very positive → high contrast
]

class MoodColorGrader:
    """Apply emotional color grading to storyboard frames."""
    
    def __init__(self):
        self.curves = GRADE_CURVES
        # Use default font if custom font not available
        try:
            self.font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 16)
        except:
            self.font = ImageFont.load_default()
    
    def select_grade(self, emotional_valence: float) -> ColorGrade:
        """Map emotional valence to appropriate color grade."""
        for low, high, grade in EMOTION_TO_GRADE:
            if low <= emotional_valence <= high:
                return grade
        return ColorGrade.NATURAL
    
    def apply_grade(self, image: Image.Image, grade: ColorGrade) -> Image.Image:
        """Apply color grade using Pillow point() LUT."""
        lut = self.curves[grade]
        r, g, b = image.split()
        r = r.point(lut.r_curve.tolist())
        g = g.point(lut.g_curve.tolist())
        b = b.point(lut.b_curve.tolist())
        return Image.merge('RGB', (r, g, b))
    
    def embed_metadata(self, image: Image.Image, beat: Beat) -> Image.Image:
        """Overlay shot metadata at bottom of frame."""
        draw = ImageDraw.Draw(image)
        text = f"SHOT {beat.position:03d} | {beat.lens.focal_length_mm[0]}mm | {beat.lens.aperture[0]} | {beat.shot_type.value.upper()}"
        
        # Semi-transparent background bar
        overlay = Image.new('RGBA', image.size, (0, 0, 0, 0))
        overlay_draw = ImageDraw.Draw(overlay)
        bar_height = 30
        overlay_draw.rectangle(
            [(0, image.height - bar_height), (image.width, image.height)],
            fill=(0, 0, 0, 180)
        )
        
        # Composite overlay
        image_rgba = image.convert('RGBA')
        composited = Image.alpha_composite(image_rgba, overlay)
        
        # Draw text
        draw = ImageDraw.Draw(composited)
        bbox = draw.textbbox((0, 0), text, font=self.font)
        text_width = bbox[2] - bbox[0]
        x = (image.width - text_width) // 2
        y = image.height - bar_height + 6
        draw.text((x, y), text, fill=(255, 255, 255, 255), font=self.font)
        
        return composited.convert('RGB')
    
    def process_frame(self, image: Image.Image, beat: Beat) -> Image.Image:
        """Full pipeline: grade + metadata for a storyboard frame."""
        grade = self.select_grade(beat.emotional_target)
        graded = self.apply_grade(image, grade)
        return self.embed_metadata(graded, beat)
```

---

## 6. Concept Enrichment: Frontend Preprocessing

### 6.1 Keyword Extraction Without Heavy Dependencies

Concept enrichment transforms a user's raw text ("fisherman at dawn") into structured metadata for template generation. This requires **keyword extraction** that identifies: location ("boat"), time of day ("dawn"), subject ("fisherman"), and mood (implied by time). The YAKE (Yet Another Keyword Extractor) library  [(Medium)](https://medium.com/@linz07m/yake-simple-and-smart-keyword-extraction-16089f235d64)  is the optimal choice for this task: it is **completely unsupervised** (no training data), **language-independent**, operates statistically without requiring stopword lists, and has a minimal footprint (approximately 2MB install). YAKE scores keywords using five statistical features: term frequency, word position (earlier words weighted higher), word context (co-occurrence with other terms), word capitalization, and sentence boundaries. The output is a ranked list of keywords with relevance scores where lower scores indicate higher importance.

RAKE (Rapid Automatic Keyword Extraction)  [(ml-digest.com)](https://ml-digest.com/rake-and-yake-keyword-extractor/)  is an alternative that is even faster but requires a stopword list, making it less robust for short or informal concept text. For the director's use case—typically short concept descriptions of 5-50 words—YAKE's statistical approach outperforms RAKE because it doesn't rely on stopword removal and can extract meaningful phrases from very short texts. Both libraries are dramatically lighter than alternatives like spaCy (which requires 50MB+ of model downloads) or KeyBERT (which uses transformer embeddings and is unsuitable for the 2GB constraint).

### 6.2 Prompt Expansion and Default Inference

Once keywords are extracted, the system applies **expansion rules** to flesh out sparse concepts. If the user provides "fisherman," the system expands to "fisherman at golden hour on a boat, weathered hands casting a net, mist rising from the water" by looking up each extracted keyword in an **expansion dictionary** that maps common subjects to richer descriptive phrases. Time-of-day inference uses keyword matching: "dawn," "sunrise," "morning" → golden hour AM; "sunset," "dusk," "evening" → golden hour PM; "night," "dark" → blue hour/night; missing time specification defaults based on the emotional arc (positive arcs default to golden hour, negative arcs to overcast). Lighting is inferred from time + mood keywords: "melancholy" + "evening" → cool blue hour lighting; "hopeful" + "morning" → warm golden backlighting.

### 6.3 FastAPI Implementation: Concept Enrichment

```python
import yake
import re
from typing import Dict, List, Optional
from dataclasses import dataclass

@dataclass
class EnrichedConcept:
    original_text: str
    keywords: List[tuple]  # (keyword, score)
    location: Optional[str]
    time_of_day: Optional[str]
    subject: Optional[str]
    mood: Optional[str]
    expanded_prompt: str
    defaults_applied: List[str]

class ConceptEnricher:
    """Extract and expand user concept text for template generation."""
    
    # Expansion dictionary for common subjects
    EXPANSIONS = {
        "fisherman": "weathered fisherman on a wooden boat, hands casting nets, sea mist",
        "city": "dense urban landscape, towering architecture, street-level energy",
        "forest": "dense woodland canopy, dappled sunlight, moss-covered terrain",
        "desert": "vast arid dunes, heat shimmer, stark shadows, endless horizon",
    }
    
    TIME_KEYWORDS = {
        "golden_hour_am": ["dawn", "sunrise", "morning", "early"],
        "golden_hour_pm": ["sunset", "dusk", "evening", "twilight"],
        "night": ["night", "midnight", "dark", "noir"],
        "midday": ["noon", "midday", "afternoon"],
    }
    
    MOOD_KEYWORDS = {
        "melancholy": ["sad", "melancholy", "lonely", "grief", "loss"],
        "hopeful": ["hope", "hopeful", "joy", "triumph", "victory"],
        "tense": ["tense", "thriller", "danger", "chase", "escape"],
        "intimate": ["love", "romance", "intimate", "tender", "connection"],
    }
    
    def __init__(self):
        # YAKE: lightweight, no training data needed
        self.kw_extractor = yake.KeywordExtractor(
            lan="en", 
            n=2,           # Max 2-gram phrases
            dedupLim=0.9,  # Deduplication threshold
            top=10         # Return top 10 keywords
        )
    
    def _detect_category(self, text: str, keyword_dict: Dict[str, List[str]]) -> Optional[str]:
        """Detect which category keywords appear in text."""
        text_lower = text.lower()
        for category, keywords in keyword_dict.items():
            if any(kw in text_lower for kw in keywords):
                return category
        return None
    
    def enrich(self, concept_text: str, emotional_arc: str = "cinderella") -> EnrichedConcept:
        """Full enrichment pipeline: extract → infer → expand."""
        defaults_applied = []
        
        # Step 1: Keyword extraction with YAKE
        keywords = self.kw_extractor.extract_keywords(concept_text)
        
        # Step 2: Categorize keywords
        time_of_day = self._detect_category(concept_text, self.TIME_KEYWORDS)
        mood = self._detect_category(concept_text, self.MOOD_KEYWORDS)
        
        # Step 3: Apply defaults where missing
        if not time_of_day:
            # Default based on emotional arc
            if emotional_arc in ["rags_to_riches", "cinderella"]:
                time_of_day = "golden_hour_pm"
            else:
                time_of_day = "overcast"
            defaults_applied.append(f"time_of_day defaulted to {time_of_day}")
        
        if not mood:
            mood = "contemplative"
            defaults_applied.append(f"mood defaulted to {mood}")
        
        # Step 4: Extract subject (highest-ranked keyword)
        subject = keywords[0][0] if keywords else None
        
        # Step 5: Expand prompt
        expanded = concept_text
        if subject and subject.lower() in self.EXPANSIONS:
            expanded = self.EXPANSIONS[subject.lower()]
        
        # Add inferred descriptors
        descriptors = []
        if time_of_day:
            time_desc = time_of_day.replace("_", " ")
            descriptors.append(time_desc)
        if mood:
            descriptors.append(mood)
        
        if descriptors:
            expanded += ", " + ", ".join(descriptors)
        
        return EnrichedConcept(
            original_text=concept_text,
            keywords=keywords,
            location=None,  # Would need NER for precise location extraction
            time_of_day=time_of_day,
            subject=subject,
            mood=mood,
            expanded_prompt=expanded,
            defaults_applied=defaults_applied
        )
```

---

## 7. Client-Side Caching: Offline-First for React Native

### 7.1 localStorage Patterns for Scriptment Storage

The client-side cache ensures users can access their scriptments even without network connectivity. The implementation uses **AsyncStorage** (the React Native equivalent of localStorage) with a structured key scheme: `scriptment:{project_id}` stores the full scriptment JSON, `scriptment_list` stores the index of all projects with metadata, and `sync_queue` tracks pending server updates. Each cached entry includes `updated_at` and `synced_at` timestamps. The sync strategy is straightforward: if `synced_at` is missing or older than `updated_at`, the entry needs synchronization  [(DEV Community)](https://dev.to/cathylai/building-offline-first-sync-in-react-native-a-practical-approach-mynexthome-4im6) .

Storage quotas in React Native AsyncStorage are typically limited only by available device storage (unlike the 5-10MB browser localStorage limit), so storing dozens of full scriptments locally is feasible. Each scriptment JSON averages 50-200KB, meaning even 100 cached projects consume only 5-20MB of device storage. The system implements a **project count cap** (50 local projects) with LRU eviction to prevent unbounded growth.

### 7.2 Sync Strategy and Cache Invalidation

The sync mechanism follows an **offline-first, timestamp-guided** pattern  [(DEV Community)](https://dev.to/cathylai/building-offline-first-sync-in-react-native-a-practical-approach-mynexthome-4im6) : (1) all writes update local storage immediately with the current `updated_at` timestamp; (2) a background sync task (triggered on network connectivity events) iterates through all local entries and pushes those with `updated_at > synced_at` to the FastAPI backend; (3) the server is treated as the **source of truth**—if a server response indicates a newer version exists, the local copy is overwritten; (4) on successful server sync, `synced_at` is updated to match `updated_at`. Cache invalidation for regenerated scriptments is explicit: when a user requests regeneration, the local copy is marked `invalidated: true` and the next sync triggers a full re-generation on the server.

### 7.3 Implementation Pattern

```typescript
// React Native client-side caching pattern
interface CachedScriptment {
  projectId: string;
  conceptText: string;
  beats: Beat[];
  updatedAt: number;
  syncedAt: number | null;
  invalidated: boolean;
}

class ScriptmentCache {
  private SYNC_KEY = 'scriptment_sync_queue';
  
  async get(projectId: string): Promise<CachedScriptment | null> {
    const data = await AsyncStorage.getItem(`scriptment:${projectId}`);
    return data ? JSON.parse(data) : null;
  }
  
  async saveLocal(scriptment: CachedScriptment): Promise<void> {
    scriptment.updatedAt = Date.now();
    scriptment.invalidated = false;
    await AsyncStorage.setItem(
      `scriptment:${scriptment.projectId}`,
      JSON.stringify(scriptment)
    );
    // Add to sync queue
    const queue = await this.getSyncQueue();
    queue.push(scriptment.projectId);
    await AsyncStorage.setItem(this.SYNC_KEY, JSON.stringify([...new Set(queue)]));
  }
  
  async syncToServer(apiClient: ApiClient): Promise<void> {
    const queue = await this.getSyncQueue();
    for (const projectId of queue) {
      const local = await this.get(projectId);
      if (!local || local.syncedAt && local.syncedAt >= local.updatedAt) {
        continue; // Already synced
      }
      try {
        await apiClient.post('/scriptments/sync', local);
        local.syncedAt = Date.now();
        await AsyncStorage.setItem(`scriptment:${projectId}`, JSON.stringify(local));
      } catch (e) {
        console.error(`Sync failed for ${projectId}:`, e);
        // Leave in queue for retry
      }
    }
  }
  
  needsSync(projectId: string): Promise<boolean> {
    // Returns true if local changes haven't been synced
    const local = await this.get(projectId);
    return !local?.syncedAt || local.syncedAt < local.updatedAt;
  }
}
```

---

## 8. Lightweight ML on VPS: Feasibility and Alternatives

### 8.1 scikit-learn: Too Heavy for 2GB

Scikit-learn is the standard library for TF-IDF vectorization and cosine similarity, but its resource footprint makes it unsuitable for the 2GB VPS constraint. The library itself consumes approximately 35MB of disk space, but its runtime memory usage is the primary concern: `TfidfVectorizer` stores the complete vocabulary as a Python dictionary, which for 1000 cached projects with diverse vocabulary can consume 50-100MB of RAM  [(Zyte)](https://www.zyte.com/blog/optimizing-memory-usage-of-scikit-learn-models-using-succinct-tries/) . Research on scikit-learn memory optimization demonstrates that vocabulary storage is the dominant cost, with `CountVectorizer` requiring 5.9MB to serialize a modest vocabulary versus 371KB for a trie-based alternative  [(Zyte)](https://www.zyte.com/blog/optimizing-memory-usage-of-scikit-learn-models-using-succinct-tries/) .

More critically, scikit-learn's design assumes data fits in memory. For the target scale of fewer than 1000 cached projects, this is true, but the memory overhead leaves insufficient headroom for FastAPI (~100MB), SQLite (~50MB), the OS (~300MB), and concurrent request processing. The risk of memory exhaustion during peak usage makes scikit-learn an imprimary dependency.

### 8.2 sqlite-vec: The Recommended Alternative

`sqlite-vec`  [(Github)](https://github.com/asg017/sqlite-vec)  replaces scikit-learn for vector search with near-zero memory overhead. Vectors are stored on disk in SQLite's native format and loaded on-demand during queries. Benchmarks demonstrate that `sqlite-vec` performs KNN queries on 1 million 128-dimensional vectors in 17-35ms  [(alexgarcia.xyz)](https://alexgarcia.xyz/blog/2024/sqlite-vec-stable-release/index.html) , which for the target cache of 1000 projects with 100-dimensional TF-IDF vectors means query times well under 10ms. The extension is written in pure C with no Python dependencies beyond `numpy` for array serialization, and it runs on devices as constrained as the Raspberry Pi Zero.

For projects that need approximate nearest-neighbor indexing (scaling beyond 10,000 vectors), `sqlite-vec` will eventually add IVF and HNSW indexes  [(alexgarcia.xyz)](https://alexgarcia.xyz/blog/2024/sqlite-vec-stable-release/index.html) , but for the current use case, its brute-force search is both sufficient and deterministic. The deterministic nature is actually an advantage for caching: approximate methods can non-deterministically miss near-neighbors, while exact brute-force guarantees consistent cache hit behavior.

### 8.3 numpy-Only TF-IDF: The Minimal Implementation

For projects that prefer not to use C extensions, a **pure numpy TF-IDF implementation** achieves identical results with under 100 lines of code. The approach uses `scipy.sparse.csr_matrix` to store the document-term matrix in compressed sparse row format, which for a vocabulary of 500 terms and 1000 documents uses approximately 2MB of memory (versus 50-100MB for scikit-learn's dense dictionary approach). Cosine similarity computes as the dot product of L2-normalized vectors, a single numpy operation that completes in microseconds for 1000 vectors. This approach is recommended for maximum portability: it requires only numpy (15MB install) and scipy, with no C extensions to compile.

### 8.4 VPS Memory Budget

| Component | Memory (MB) | Notes |
|---|---|---|
| Ubuntu 24.04 base | 200 | Minimal server install |
| Python runtime + FastAPI | 80 | Uvicorn worker |
| SQLite (with cache) | 50 | Database + sqlite-vec mmap |
| diskcache | 10 | File-backed, minimal RAM |
| Pillow (image processing) | 30 | Only when actively grading |
| numpy | 25 | Shared library |
| YAKE + dependencies | 15 | Keyword extraction |
| Gunicorn overhead | 30 | Process management |
| **Headroom** | **~560** | Available for concurrent requests |
| **Total used** | **~440** | Well within 2GB limit |

The memory budget demonstrates that the recommended stack (FastAPI + sqlite-vec + diskcache + Pillow + numpy + YAKE) consumes approximately 440MB, leaving 1.5GB for OS buffers, concurrent requests, and growth. This is a comfortable margin that would not be achievable with scikit-learn, Redis (separate process ~50MB), or transformer-based NLP models.

### 8.5 Complete FastAPI Application Structure

```python
# main.py - Complete FastAPI application integrating all components
from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List
import asyncio
import time

app = FastAPI(title="Director's Eye API", version="2.0")

# Initialize components (singleton pattern)
beat_engine = None
validator = None
scheduler = None
grader = None
cache = None
enricher = None

@app.on_event("startup")
async def startup():
    global beat_engine, validator, scheduler, grader, cache, enricher
    # Lazy initialization keeps memory footprint minimal
    pass

class GenerateRequest(BaseModel):
    concept: str
    emotional_arc: EmotionalArc = EmotionalArc.CINDERELLA
    beat_count: int = 40
    bypass_cache: bool = False

class GenerateResponse(BaseModel):
    project_id: str
    beats: List[Beat]
    schedule: List[ShootBlock]
    from_cache: bool
    corrections: List[BeatValidationError] = []
    generation_time_ms: int

@app.post("/generate", response_model=GenerateResponse)
async def generate(request: GenerateRequest):
    start = time.time()
    
    # Step 1: Enrich concept
    if enricher is None:
        enricher = ConceptEnricher()
    enriched = enricher.enrich(request.concept, request.emotional_arc.value)
    
    # Step 2: Check cache
    if cache is None:
        cache = SemanticConceptCache()
    
    if not request.bypass_cache:
        cached = cache.get(enriched.expanded_prompt, request.emotional_arc.value)
        if cached:
            beats = [Beat.parse_raw(b) for b in cached]  # From cache
            return GenerateResponse(
                project_id=hashlib.sha256(request.concept.encode()).hexdigest()[:16],
                beats=beats,
                schedule=ShootScheduler().create_schedule(beats),
                from_cache=True,
                generation_time_ms=int((time.time() - start) * 1000)
            )
    
    # Step 3: Generate beat template (code, not AI)
    if beat_engine is None or beat_engine.arc != request.emotional_arc:
        beat_engine = BeatTemplateEngine(request.emotional_arc, request.beat_count)
    beats = beat_engine.generate_template()
    
    # Step 4: Validate and auto-fix
    if validator is None:
        validator = FilmGrammarValidator(beat_engine)
    beats, corrections = validator.validate_and_fix(beats)
    
    # Step 5: Generate creative descriptions (AI - the 20%)
    # This is where the LLM API call happens
    beats = await _generate_descriptions(beats, enriched)
    
    # Step 6: Create production schedule
    if scheduler is None:
        scheduler = ShootScheduler()
    schedule = scheduler.create_schedule(beats)
    
    # Step 7: Cache result
    cache.put(enriched.expanded_prompt, request.emotional_arc.value, 
              json.dumps([b.json() for b in beats]))
    
    return GenerateResponse(
        project_id=hashlib.sha256(request.concept.encode()).hexdigest()[:16],
        beats=beats,
        schedule=schedule,
        from_cache=False,
        corrections=corrections,
        generation_time_ms=int((time.time() - start) * 1000)
    )

async def _generate_descriptions(beats: List[Beat], enriched: EnrichedConcept) -> List[Beat]:
    """Call LLM API for creative descriptions only."""
    # Integration with DeepSeek/Grok/OpenAI
    # Send only the beat structure + enriched concept
    # Receive descriptions to populate each beat
    # Cost: ~$0.00007 per call (DeepSeek)
    pass

# Deployment: gunicorn -w 3 -k uvicorn.workers.UvicornWorker main:app
# Memory per worker: ~120MB
# Total with 3 workers: ~360MB + OS overhead = ~600MB
```

---

## 9. Library Recommendations Summary

### 9.1 Complete Dependency Stack

| Library | Purpose | Install Size | RAM (runtime) | Alternative | Why This Choice |
|---|---|---|---|---|---|
| **fastapi** | Web framework | 5 MB | 30 MB | Flask, Django | Native async, auto-docs, Pydantic integration |
| **uvicorn** | ASGI server | 3 MB | 15 MB | Gunicorn pure | High-performance async, low memory |
| **pydantic** | Validation | 5 MB | 10 MB | jsonschema, dataclasses | v2 is 5-50x faster, native FastAPI support |
| **pillow** | Image processing | 3 MB | 30 MB (peak) | OpenCV (150MB) | PIL is sufficient for LUT + text overlay |
| **pillow-lut-tools** | LUT manipulation | 1 MB | 5 MB | Custom numpy LUTs | HALD support, professional grade |
| **sqlite-vec** | Vector search | 5 MB | 10 MB | scikit-learn (35MB) | Runs on Pi Zero, ACID, unified storage |
| **diskcache** | Exact-match cache | 0.5 MB | 5 MB | Redis (+50MB process) | Pure Python, faster than Redis for local |
| **yake** | Keyword extraction | 2 MB | 15 MB | spaCy (+500MB models) | No training data, 2MB, unsupervised |
| **numpy** | Array operations | 15 MB | 20 MB | Pure Python lists | Essential for TF-IDF and image arrays |
| **jinja2** | Template rendering | 1 MB | 5 MB | String formatting | Structured prompt templates for LLM |
| **httpx** | HTTP client | 2 MB | 10 MB | requests, aiohttp | Async support, smaller than aiohttp |
| **python-dotenv** | Config loading | 0.1 MB | 1 MB | os.environ | Standard for 12-factor apps |
| **Total** | | **~42.6 MB** | **~100 MB baseline** | | |

### 9.2 Libraries to Avoid on 2GB VPS

| Library | Size | Why Avoid | Replacement |
|---|---|---|---|
| **scikit-learn** | 35 MB + 50-100MB RAM | Vocabulary dict bloat, overkill for <1000 docs | sqlite-vec + numpy TF-IDF |
| **spaCy** | 15 MB + 500MB models | Model download requirement, massive footprint | YAKE (2MB, no models) |
| **Redis** | 50 MB process | Separate process, network overhead, memory duplication | diskcache + sqlite-vec |
| **OpenCV** | 150 MB | Far exceeds need (LUT + text only) | Pillow (3MB) |
| **transformers** | 200 MB+ | HuggingFace models are GB-scale | YAKE (statistical, no ML) |
| **torch/tensorflow** | 500 MB+ | GPU-focused, completely unnecessary | numpy (15MB) |

![Library Size Comparison](library_comparison.png)

---

## 10. Open-Source Projects and Prior Art

### 10.1 Film Production Tools

The film production software landscape is dominated by commercial offerings. **StudioBinder**  [(worldmetrics.org)](https://worldmetrics.org/best/film-production-management-software/)  provides the most complete script-to-schedule workflow with call sheets, shot lists, and production boards. **Studiovity**  [(studiovity.com)](https://studiovity.com/)  adds AI-assisted screenwriting with beat boards. **Shot Lister**  [(worldmetrics.org)](https://worldmetrics.org/best/film-production-management-software/)  focuses specifically on shot-by-shot planning with per-shot status tracking. **WonderUnit's Shot Generator**  [(Wonder Unit)](https://wonderunit.com/shot-generator/)  is notable for its early AI-generated shot compositions, though it lacks the algorithmic structure generation proposed here. **Stencil**  [(stencil.one)](https://stencil.one/how-to-create-shot-lists/)  offers shot list creation with reference image support. None of these tools expose APIs or algorithmic generation suitable for backend integration—they are standalone applications rather than libraries.

### 10.2 Research Projects

The **Patterns language for cinematographic sequences**  [(Inria)](https://inria.hal.science/hal-01150905/file/WICED2015.pdf)  from INRIA represents the most relevant academic work, defining a formal grammar for shot sequences including `intensify`, `shot-reverse-shot`, and `crossline` patterns. The **Emotional Arc Guided Procedural Generation**  [(arXiv.org)](https://arxiv.org/html/2508.02132v1)  paper demonstrates practical application of Reagan et al.'s six arcs to game level generation using GPT-4o-mini with directed acyclic graphs, validating the architecture proposed in this report. **ShotDirector**  [(arXiv.org)](https://arxiv.org/html/2512.10286v1)  provides a dataset (ShotWeaver40K) of shot transitions with cinematic annotations, useful for training or validating transition quality. The **NRCLex** emotion analysis framework  [(Global journal of Business and Integral Security)](https://www.gbis.ch/index.php/gbis/article/download/432/347/1068)  provides lexicon-based emotion extraction that could enhance the emotional targeting system.

---

## 11. Deployment Architecture

### 11.1 Gunicorn + Uvicorn Configuration

For the 2GB VPS, the optimal configuration uses **Gunicorn as process manager** with **Uvicorn workers** for async handling  [(RamNode®)](https://www.ramnode.com/guides/fastapi) . The worker count formula `(CPU cores × 2) + 1` gives 3-5 workers for a typical 1-2 core VPS. With the memory budget of ~120MB per worker, 3 workers consume ~360MB total. Gunicorn's `--max-requests` setting (10000) prevents memory leaks by recycling workers, and `--preload` reduces memory by sharing application code across forked workers. Uvicorn's `[standard]` extras install `uvloop` (libuv-based event loop) and `httptools` (HTTP parser) for C-level performance  [(PyPI)](https://pypi.org/project/uvicorn/) .

```bash
# gunicorn.conf.py for 2GB VPS
import multiprocessing

bind = "127.0.0.1:8000"
workers = multiprocessing.cpu_count() * 2 + 1  # 3-5 workers
worker_class = "uvicorn.workers.UvicornWorker"
worker_tmp_dir = "/dev/shm"  # RAM-based temp for performance
max_requests = 10000
max_requests_jitter = 1000    # Stagger worker restarts
preload_app = True            # Share memory across workers
timeout = 120
keepalive = 5
```

### 11.2 Nginx Reverse Proxy

Nginx sits in front of Gunicorn handling static file serving, SSL termination, and connection buffering. For a 2GB VPS, the Nginx worker count should be limited to `auto` (one per CPU core) with `worker_connections 512` to prevent memory exhaustion. Gzip compression reduces JSON response sizes by 60-70%, and `proxy_cache` can cache identical GET requests for the `/health` endpoint and static assets.

### 11.3 Monitoring and Alerting

With 2GB RAM, monitoring is essential. The system should track: (1) **memory usage per process** via `psutil` exposed on a `/metrics` endpoint; (2) **cache hit rate** logged for every request; (3) **LLM API latency** and cost tracking; (4) **disk space** for SQLite growth. A simple health check endpoint verifies database connectivity and cache accessibility. Memory alerts trigger at 1.5GB total usage (75% of capacity), prompting investigation before the OOM killer intervenes.

---

## 12. Conclusion: The 80/20 Split in Practice

This research demonstrates that **80% of scriptment generation logic can indeed move from AI to code** without sacrificing creative quality. The deterministic components—narrative structure, shot type rotation, lens assignment, emotional arc progression, grammar validation, scheduling optimization, color grading, and concept caching—are all better implemented as explicit algorithms than as LLM prompts. Code provides guarantees that AI cannot: exact shot variety enforcement, precise emotional curve following, deterministic cache behavior, and sub-millisecond response times. The remaining 20%—beat descriptions, dialogue, mood text, and creative expansion—remains the domain of LLMs, where their generative capabilities shine without the burden of structural enforcement.

The resulting architecture operates comfortably within the **2GB RAM constraint** using a 43MB Python dependency stack and ~600MB total runtime footprint. By replacing scikit-learn with sqlite-vec, eliminating Redis in favor of diskcache, using YAKE instead of spaCy, and building a numpy-only TF-IDF pipeline, the system achieves semantic concept caching and keyword extraction that would typically require 500MB+ of dependencies with under 50MB. The FastAPI + Gunicorn + Uvicorn deployment with 3 workers provides sufficient concurrency for a production application while leaving 1.4GB of RAM available for peak loads and OS operations.

The key insight across all eight research areas is that **film production planning is a structured discipline with centuries of accumulated conventions**. These conventions—shot sizes, focal lengths, narrative arcs, lighting conditions, color theory—exist precisely because they work, and they can be encoded as deterministic rules. The AI's role is not to invent structure but to populate it with creative content: the words that describe a shot, the dialogue between characters, the sensory details that make a scene come alive. By separating structure from creativity, the Director's Eye system achieves both reliability and imagination at a fraction of the cost.

---

## References

 [(Global journal of Business and Integral Security)](https://www.gbis.ch/index.php/gbis/article/download/432/347/1068) : Ramappa, P. "Emotionally Intelligent Storytelling Through AI and ML Using Emotional Arcs." Swiss School of Business Management, Geneva. GBIS Proceedings. Analysis of 3,500 films using NRCLex for emotion extraction and K-means clustering into six story shapes.

 [(CFILT - IITB)](https://www.cfilt.iitb.ac.in/resources/surveys/2022/vishal-ampsg-survey-28june22.pdf) : IIT Bombay CFILT. "Survey: Automatic Movie Plot And Script Generation." Comprehensive survey of narrative generation techniques including Hero's Journey (17 steps), Save the Cat beat sheet (15-40 beats), and emotional arc frameworks.

 [(Inria)](https://inria.hal.science/hal-01150905/file/WICED2015.pdf) : Ronfard, R., et al. "Stylistic Patterns for Generating Cinematographic Sequences." INRIA Research Report. Formal language (Patterns) for shot sequence generation with operations: initial, next, last, all, none, ordered, and transition constraints.

 [(Github)](https://github.com/pydantic/pydantic/discussions/5135) : Pydantic GitHub Discussions. "Does Pydantic natively support schema validation of JSON schemas?" 2023. Discussion of Pydantic v2's scope (data validation, not JSON Schema validation) and integration with jsonschema library.

 [(Noam Kroll)](https://noamkroll.com/this-simple-beat-sheet-technique-will-help-you-finish-your-feature-screenplay-in-record-time/) : Kroll, N. "This Simple Beat Sheet Technique Will Help You Finish Your Feature Screenplay." 2022. 40-beat expansion of Save the Cat structure with ~2-3 pages per beat translating to 100-120 page screenplays.

 [(igelsociety.org)](https://discourse.igelsociety.org/t/annotation-and-prediction-of-emotion-arcs-of-movies/362) : Cranenburgh, A. van. "Annotation and Prediction of Emotion Arcs of Movies." University of Groningen, 2023. Empirical study validating emotional arcs against manual annotations using subtitle sentiment analysis.

 [(Couchbase)](https://www.couchbase.com/blog/validate-json-documents-in-python-using-pydantic/) : Couchbase Blog. "Validate JSON Documents in Python using Pydantic." 2022. Pydantic v1 BaseModel patterns for JSON validation including strict mode, custom types (HttpUrl), and parse_obj error handling.

 [(arXiv.org)](https://arxiv.org/html/2512.10286v1) : "ShotDirector: Directorially Controllable Multi-Shot Video Generation with Cinematographic Transitions." arXiv:2512.10286. ShotWeaver40K dataset with 40K annotated shot transitions including POV, cut-in, cut-out, and multi-angle types.

 [(Tabletop Composer)](https://www.tabletopcomposer.com/post/how-to-score-an-emotional-arc-not-just-a-scene) : "How to Score an Emotional Arc (Not Just a Scene)." Tabletop Composer, 2025. Four emotional parameters for arc tracking: Valence, Size, Energy/Movement, and Gesture.

 [(Wonder Unit)](https://wonderunit.com/shot-generator/) : WonderUnit. "Shot Generator." 2019. AI-powered shot generation tool integrated with Storyboarder for camera positioning and character posing in 3D space.

 [(arXiv.org)](https://arxiv.org/html/2508.02132v1) : "Emotional Arc Guided Procedural Game Level Generation." arXiv:2508.02132. Practical implementation of Reagan et al.'s six arcs using GPT-4o-mini with DAG-based story graphs and AI chaining for narrative generation.

 [(Filmmakers Academy)](https://www.filmmakersacademy.com/emotional-arc/) : Filmmakers Academy. "Emotional Arc: Breaking Down Your Screenplay." 2022. Analysis of David Fincher's cinematography in The Social Network as emotional arc illustration.

 [(PyImageSearch)](https://pyimagesearch.com/2026/04/27/semantic-caching-for-llms-fastapi-redis-and-embeddings/) : Singh, V. "Semantic Caching for LLMs: FastAPI, Redis, and Embeddings." PyImageSearch, 2026. Layered caching strategy: exact match → semantic match (cosine similarity) → LLM fallback with confidence scoring.

 [(spheron.network)](https://www.spheron.network/blog/semantic-cache-llm-inference-gpu-cloud/) : Spheron Network. "Semantic Caching for LLM Inference." 2026. GPTCache and Redis Vector Cache patterns with similarity threshold tuning by workload type (FAQ: 0.90-0.93, RAG: 0.92-0.95).

 [(Redis)](https://redis.io/tutorials/semantic-caching-with-redis-langcache/) : Redis. "Semantic Caching with Redis LangCache." 2026. FastAPI + LangCache implementation with automatic embedding and similarity matching through Redis API.

 [(Codecademy)](https://www.codecademy.com/resources/docs/pillow/image/point) : Codecademy. "Python: Pillow .point() - Image Module." 2025. Documentation for applying lookup tables and functions to each pixel using Image.point(lut, mode).

 [(Github)](https://github.com/homm/pillow-lut-tools) : homm. "pillow-lut-tools: Lookup tables loading, manipulating, and generating for Pillow." GitHub. HALD image loading, rgb_color_enhance, and filter composition for professional color grading.

 [(litepanels.com)](https://www.litepanels.com/en/applications/the-art-of-production-scheduling/) : Litepanels. "The Art of Production Scheduling." 2025. Production scheduling hierarchy: lighting constraints → location grouping → lens continuity → equipment grouping.

 [(DEV Community)](https://dev.to/cathylai/building-offline-first-sync-in-react-native-a-practical-approach-mynexthome-4im6) : Lai, C. "Building Offline-First Sync in React Native." Dev.to, 2025. Timestamp-based sync pattern using AsyncStorage with needsSync = !syncedAt || updatedAt > syncedAt.

 [(ml-digest.com)](https://ml-digest.com/rake-and-yake-keyword-extractor/) : ML-Digest. "RAKE vs. YAKE: Which Keyword Extractor Should You Use?" 2026. Comparative analysis: RAKE requires stopword lists and is faster; YAKE is language-independent and more robust for short texts.

 [(Medium)](https://medium.com/@linz07m/yake-simple-and-smart-keyword-extraction-16089f235d64) : Lince. "YAKE: Simple and Smart Keyword Extraction." Medium, 2025. Unsupervised keyword extraction using five statistical features (frequency, position, context, capitalization, sentence boundaries).

 [(bastakiss.com)](https://bastakiss.com/blog/extracting-keywords-from-text-with-python-bastaki-software-solutions/) : Bastakiss. "Extracting Keywords from Text with Python." 2025. Survey of extraction libraries: RAKE (simple), spaCy (NLP-heavy), KeyBERT (transformer-based), YAKE (lightweight statistical).

 [(PyPI)](https://pypi.org/project/fastapi-easy-cache/) : PyPI. "fastapi-easy-cache." SQLite-based caching for FastAPI with decorator pattern for endpoint result caching.

 [(towardsdatascience.com)](https://towardsdatascience.com/keyword-extraction-a-benchmark-of-7-algorithms-in-python-8a905326d93f/) : Towards Data Science. "Keyword Extraction - A Benchmark of 7 Algorithms in Python." 2025. Benchmark of RAKE, YAKE, PKE, KeyBERT, Spacy on 2000 documents comparing extraction quality and execution time.

 [(reddit.com)](https://www.reddit.com/r/Python/comments/4bylcs/diskcache_notsucky_filebased_cache_backend/) : Reddit r/Python. "diskcache: Not-Sucky Filebased Cache Backend." Discussion of diskcache's SQLite3 backend with thread-safe and process-safe operations.

 [(studiovity.com)](https://studiovity.com/) : Studiovity. "Pre Production Software for Film Production Management." AI-assisted screenwriting with 100K+ downloads, used by Netflix, Disney+, HBO, BBC productions.

 [(Github)](https://github.com/scikit-learn/scikit-learn/blob/main/sklearn/feature_extraction/text.py) : scikit-learn GitHub. "sklearn/feature_extraction/text.py." TfidfVectorizer implementation showing vocabulary dictionary storage and HashingVectorizer as stateless alternative.

 [(worldmetrics.org)](https://worldmetrics.org/best/film-production-management-software/) : WorldMetrics. "Best Film Production Management Software 2026." Comparison of StudioBinder (9.2/10), Movie Magic Scheduling (8.4/10), Shot Lister (8.3/10), and StudioPlan (7.6/10).

 [(stencil.one)](https://stencil.one/how-to-create-shot-lists/) : Stencil. "Ridiculously Easy Shot List Tool For Planning Films & Docs." 2023. Shot list creation with reference images, sketches, and production still upload for real-time project visualization.

 [(wifitalents.com)](https://wifitalents.com/best/film-production-planning-software/) : WiFi Talents. "Top 10 Best Film Production Planning Software of 2026." StudioBinder ranked #1 for script-to-schedule workflows and production document generation.

 [(youtube.com)](https://www.youtube.com/watch?v=xdlrQ0-okZc) : YouTube. "Keyword Extraction in Python via RAKE." Andrew Porter, 2022. Tutorial on rake-nltk library installation and usage for phrase extraction.

 [(Medium)](https://medium.com/@sharma.tanish096/nlp-e3b976b5664d) : Sharma, T. "NLP: Implementation of Tf-Idf without using SK-learn." Medium, 2022. Complete numpy/scipy implementation of TF-IDF from scratch with IDF calculation and sparse matrix output.

 [(Github)](https://github.com/long2ice/fastapi-cache) : GitHub. "long2ice/fastapi-cache." FastAPI caching with Redis, Memcached, DynamoDB, and in-memory backends. Supports ETag and Cache-Control headers.

 [(reddit.com)](https://www.reddit.com/r/Filmmakers/comments/12emngu/shot_list_programs/) : Reddit r/Filmmakers. "Shot list programs?" 2025. Community discussion of Shot Logic, StudioBinder alternatives, and UX preferences for shot list tools.

 [(MojoAuth)](https://mojoauth.com/implement-caching/implement-caching-with-fastapi) : MojoAuth. "Implement Caching with FastAPI." 2025. In-memory caching patterns using functools.lru_cache and third-party backends for FastAPI endpoints.

 [(GeeksForGeeks)](https://www.geeksforgeeks.org/machine-learning/fitting-data-in-chunks-vs-fitting-all-at-once-in-scikit-learn/) : GeeksforGeeks. "Fitting Data in Chunks vs. Fitting All at Once in scikit-learn." 2025. Memory efficiency strategies using partial_fit for incremental learning with large datasets.

 [(Zyte)](https://www.zyte.com/blog/optimizing-memory-usage-of-scikit-learn-models-using-succinct-tries/) : Zyte. "Optimizing memory usage of Scikit-Learn models using succinct tries." 2014. Marisa-Trie based vectorizers achieving 50x+ memory reduction; HashingVectorizer as stateless alternative.

 [(Scribd)](https://www.scribd.com/presentation/427563132/8-shot-sequence) : Scribd. "8 Shot Sequence - Film Shot Types and Their Uses." 2025. Documentation of 8 standard shot types: close up, extreme close up, POV, wide, long, top, mid, two shot.

 [(Stack Overflow)](https://stackoverflow.com/questions/25145552/tfidf-for-large-dataset) : StackOverflow. "TFIDF for Large Dataset." 2014. Gensim recommended as memory-efficient alternative; HashingVectorizer + TfidfTransformer approach for large corpora.

 [(Milvus)](https://milvus.io/ai-quick-reference/what-is-the-best-library-for-text-classification) : Milvus. "What is the best library for text classification?" 2026. scikit-learn for small/medium datasets, TensorFlow/Keras for custom neural networks, HuggingFace for state-of-the-art.

 [(langchain.js)](https://reference.langchain.com/python/langchain-community/caches) : LangChain Documentation. "caches | langchain_community." InMemoryCache, SQLiteCache, RedisCache, RedisSemanticCache, GPTCache implementations.

 [(Medium)](https://medium.com/@Shamimw/speed-up-your-llm-apps-caching-responses-with-python-and-diskcache-aef146a410d5) : Shamim. "Speed up your LLM apps: Caching Responses with Python and DiskCache." Medium, 2025. DiskCache SQLite backend for persistent LLM response caching.

 [(talkpython.fm)](https://talkpython.fm/episodes/show/534/diskcache-your-secret-python-perf-weapon) : Talk Python Podcast. "Episode #534 - diskcache: Your secret Python perf weapon." 2026. DiskCache as pure-Python SQLite-backed alternative to Redis, with multiprocess safety.

 [(psaroloco.org)](https://www.psaroloco.org/camera-shots-size-explained) : Psaroloco. "Camera Shots: Every Shot Size Explained." Comprehensive shot taxonomy: establishing, EWS, WS, FS, MWS, cowboy, MS, MCU, CU, ECU with narrative purposes.

 [(Github)](https://github.com/grantjenks/python-diskcache) : GitHub. "grantjenks/python-diskcache: Python disk-backed cache." Pure-Python, faster than Redis for local workloads, 100% test coverage, LRU/LFU eviction policies.

 [(Adobe)](https://www.adobe.com/creativecloud/video/production/cinematography/camera-shots-and-angles.html) : Adobe. "Different types of shots and camera angles in film." 2026. Professional guide to shot sizes, focal lengths (85-135mm for CU), apertures (f/1.8-f/2.8 for shallow DOF).

 [(ceaksan)](https://ceaksan.com/en/hybrid-search-fts5-vector-rrf) : Ceaksan. "Smart Search Architecture with FTS5 + Vector + RRF." 2026. Hybrid search combining SQLite FTS5 (BM25) with sqlite-vec (cosine) using Reciprocal Rank Fusion.

 [(stackademic.com)](https://blog.stackademic.com/instant-semantic-search-api-sqlite-fts5-python-fastapi-3298c6776935) : Stackademic. "Instant Semantic Search API: SQLite FTS5 + Python FastAPI." 2025. Two-step hybrid search: FTS5 match for candidates, cosine re-ranking for semantic relevance.

 [(Medium)](https://medium.com/agentsops/a-simple-semantic-search-with-python-and-fastapi-f80f2b785086) : Medium. "A simple semantic search with Python and FastAPI." 2025. SentenceTransformer + cosine similarity implementation for document search.

 [(apxml.com)](https://apxml.com/zh/courses/fastapi-ml-deployment/chapter-4-structuring-testing-fastapi/managing-dependencies) : APXML. "Managing Python Dependencies for FastAPI." 2025. requirements.txt vs Poetry for dependency management in ML API deployments.

 [(Ready TensorReady Tensor)](https://app.readytensor.ai/publications/i-built-a-semantic-search-api-using-fastapi-and-sbert-heres-how-it-works-5736VHfGiJlR) : ReadyTensor. "I Built a Semantic Search API Using FastAPI and SBERT." 2025. ~5-10ms latency for thousands of embeddings using sentence-transformers.

 [(ACL Anthology)](https://aclanthology.org/2020.emnlp-main.426.pdf) : ACL Anthology. "Modeling Protagonist Emotions for Emotion-Aware Story Generation." 2020. Emotion classifier reward function for reinforcement learning-based story generation.

 [(Springer)](https://link.springer.com/article/10.1140/epjds/s13688-016-0093-1) : Reagan, A.J., et al. "The emotional arcs of stories are dominated by six basic shapes." EPJ Data Science, 2016. Large-scale sentiment analysis of 1,327 books validating six fundamental story arcs.

 [(EFD México)](https://efd-studios.com/en/news/guide-to-camera-lenses-and-their-uses-in-filmmaking/) : EFD Studios. "Guide to Camera Lenses and Their Uses in Filmmaking." 2025. Focal length categories: wide-angle (<35mm), standard (35-70mm), short telephoto (70-135mm), long telephoto (>135mm).

 [(TutorialsPoint)](https://www.tutorialspoint.com/python_pillow/python_pillow_writing_text_on_image.htm) : Tutorialspoint. "Python Pillow - Writing Text to an Image." ImageDraw.text() method for text overlay with position, font, color, and alignment control.

 [(RamNode®)](https://www.ramnode.com/guides/fastapi) : RamNode. "FastAPI Deployment Guide." Minimum 1GB RAM VPS (2GB recommended), Gunicorn + Uvicorn workers, Nginx reverse proxy, systemd configuration.

 [(indepthcine.com)](https://www.indepthcine.com/videos/focal-length) : In Depth Cine. "Understanding Focal Length In Cinematography." 2026. Wide (16-35mm), medium (35-50mm), telephoto (75-200mm+) with emotional associations for each range.

 [(oneuptime.com)](https://oneuptime.com/blog/post/2026-01-25-background-task-processing-fastapi/view) : OneUptime. "How to Build Background Task Processing in FastAPI." 2026. Asyncio background tasks with tracked task sets for graceful shutdown.

 [(Medium)](https://medium.com/@iklobato/mastering-gunicorn-and-uvicorn-the-right-way-to-deploy-fastapi-applications-aaa06849841e) : Medium. "Mastering Gunicorn and Uvicorn: The Right Way to Deploy FastAPI." 2025. Worker configuration, memory implications, and production deployment patterns.

 [(wikipedia.org)](https://en.wikipedia.org/wiki/Wide-angle_lens) : Wikipedia. "Wide-angle lens." Technical characteristics: field of view, perspective distortion, retrofocus design for SLR cameras.

 [(Prefect 2)](https://docs.prefect.io/v3/advanced/background-tasks) : Prefect. "How to deploy a web application powered by background tasks." Multi-stage Dockerfile with separate server, task worker, and API stages.

 [(canon.ge)](https://www.canon.ge/pro/infobank/understanding-focal-length/) : Canon. "Understanding focal length in photography." Prime vs. zoom lenses, crop factor implications, and focal length categories by application.

 [(StudioBinder)](https://www.studiobinder.com/blog/focal-length-camera-lenses-explained/) : StudioBinder. "Focal Length: An Easy Guide to Using and Understanding Camera Lenses." 2025. Practical lens selection guide with focal length ranges for narrative filmmaking.

 [(apxml.com)](https://apxml.com/courses/fastapi-ml-deployment/chapter-5-async-operations-performance/using-background-tasks) : APXML. "Using Background Tasks in FastAPI for ML APIs." Logging, monitoring, cache invalidation, and queue-based downstream processing patterns.

 [(MCP Servers)](https://mcpmarket.com/tools/skills/sqlite-vector-search-sqlite-vec) : MCPMarket. "sqlite-vec: SQLite Vector Search Claude Code Skill." vec0 virtual tables, KNN queries, metadata filtering, float32/int8/bit vector support.

 [(Medium)](https://medium.com/@stephenc211/how-sqlite-vec-works-for-storing-and-querying-vector-embeddings-165adeeeceea) : Collins, S. "How sqlite-vec Works for Storing and Querying Vector Embeddings." Medium, 2025. SIMD acceleration (AVX/NEON), chunked storage, and type-safe vector operations.

 [(DEV Community)](https://dev.to/aairom/embedded-intelligence-how-sqlite-vec-delivers-fast-local-vector-search-for-ai-3dpb) : Dev.to. "How SQLite-vec Delivers Fast, Local Vector Search for AI." 2025. RAG implementation with sqlite-vec on local devices, Ollama embeddings, zero network dependencies.

 [(Medium)](https://medium.com/@JavaFusion/build-your-first-fastapi-app-from-virtual-environment-to-uvicorn-server-342e1d069900) : Medium. "Build Your First FastAPI App." 2025. Virtual environment setup, FastAPI + Uvicorn installation, and basic endpoint creation.

 [(Hacker News)](https://news.ycombinator.com/item?id=40243168) : HackerNews. "I'm writing a new vector search SQLite Extension." 2024. sqlite-vec announcement, design philosophy (brute-force first), performance benchmarks vs. Faiss.

 [(towardsdatascience.com)](https://towardsdatascience.com/retrieval-augmented-generation-in-sqlite/) : Towards Data Science. "Retrieval Augmented Generation in SQLite." 2025. sqlite-vec Python tutorial with OpenAI embeddings, KNN search, and RAG pipeline.

 [(alexgarcia.xyz)](https://alexgarcia.xyz/blog/2024/sqlite-vec-stable-release/index.html) : Garcia, A. "Introducing sqlite-vec v0.1.0." 2024. 1M vector benchmarks: 17-35ms query time, runs on Raspberry Pi Zero, WebAssembly, mobile devices.

 [(PyPI)](https://pypi.org/project/uvicorn/) : PyPI. "uvicorn." ASGI web server with [standard] extras for uvloop, httptools, websockets, and watchfiles.

 [(Uvicorn)](https://uvicorn.dev/) : Uvicorn Documentation. ASGI server implementation supporting HTTP/1.1 and WebSockets.

 [(morphic.com)](https://morphic.com/ai-glossary/Teal-and-Orange) : Morphic. "Teal and orange: the blockbuster colour grading look." Color theory explanation: complementary contrast between skin tones (warm) and shadow push (teal).

 [(Stack Overflow)](https://stackoverflow.com/questions/76659992/python-fastapi-package-python-multipart-installed-but-not-found) : StackOverflow. "Python FastAPI package python-multipart installed but not found." 2024. Uvicorn worker process handling and package resolution in virtual environments.

 [(Github)](https://github.com/asg017/sqlite-vec) : GitHub. "asg017/sqlite-vec: A vector search SQLite extension that runs anywhere." Python/Node.js/Ruby/Go/Rust bindings, vec0 virtual tables, SIMD acceleration.
